<?php

QuickBooks_Loader::load('/QuickBooks/IPP/Object.php');

class QuickBooks_IPP_Object_LegalAddress extends QuickBooks_IPP_Object
{
	
}
