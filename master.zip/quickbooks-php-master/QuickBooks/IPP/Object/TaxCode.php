<?php

QuickBooks_Loader::load('/QuickBooks/IPP/Object.php');

class QuickBooks_IPP_Object_TaxCode extends QuickBooks_IPP_Object
{
	
}
