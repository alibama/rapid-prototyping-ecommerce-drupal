<?php

class QuickBooks_User
{
	public function __construct()
	{
		
	}
}